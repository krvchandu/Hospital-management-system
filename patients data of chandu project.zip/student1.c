#include<stdio.h>
#include<stdlib.h>
#include "chandufile.h"

//----------Adding patients ----------//

void addPatient(struct patient p[],int *n){

    FILE *fp;
    fp = fopen("patientData.txt","ab");

    printf("Enter the id: ");
    scanf("%d",&p[*n].id);

    printf("Enter the name: ");
    scanf("%s",p[*n].name);

    printf("Enter the age: ");
    scanf("%d",&p[*n].age);

    printf("Enter disease: ");
    scanf(" %[^\n]",p[*n].disease);

    fwrite(&p[*n],sizeof(struct patient),1,fp);

    fclose(fp);

    (*n)++;

    printf("Patient Added Successfully!\n");
}


//----------------Display Patients-------------//

void displayPatient(){

    FILE *fp = fopen("patientData.txt","rb");

    if(fp==NULL){
        printf("No file found\n");
        return;
    }

    struct patient temp;
    int i=1;

    while(fread(&temp,sizeof(struct patient),1,fp)){

        printf("\nPatient %d\n",i++);
        printf("ID : %d\n",temp.id);
        printf("Name : %s\n",temp.name);
        printf("Age : %d\n",temp.age);
        printf("Disease : %s\n",temp.disease);
    }

    fclose(fp);
}

//----------------Search Patient-------------//

void searchPatient(){

    int id;
    printf("Enter patient ID to search: ");
    scanf("%d",&id);

    FILE *fp = fopen("patientData.txt","rb");

    struct patient temp;
    int found=0;

    while(fread(&temp,sizeof(struct patient),1,fp)){

        if(temp.id==id){

            printf("\nPatient Found\n");
            printf("ID : %d\n",temp.id);
            printf("Name : %s\n",temp.name);
            printf("Age : %d\n",temp.age);
            printf("Disease : %s\n",temp.disease);

            found=1;
            break;
        }
    }

    if(!found)
    printf("Patient not found\n");

    fclose(fp);
}


//-------------Highest Age Patient------------//

void highestPatient(){

    FILE *fp = fopen("patientData.txt","rb");

    struct patient temp,max;
    int first=1;

    while(fread(&temp,sizeof(struct patient),1,fp)){

        if(first || temp.age > max.age){
            max = temp;
            first=0;
        }
    }

    printf("\nHighest Age Patient\n");
    printf("ID : %d\n",max.id);
    printf("Name : %s\n",max.name);
    printf("Age : %d\n",max.age);
    printf("Disease : %s\n",max.disease);

    fclose(fp);
}

