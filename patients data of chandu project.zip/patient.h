//-------My header folder-----//

#ifndef CHANDUFILE_H
#define CHANDUFILE_H

struct patient{
    int id;
    char name[50];
    int age;
    char disease[100];
};


//------Functions---------//

void addPatient(struct patient p[], int *n);
void displayPatient();
void searchPatient();
void highestPatient();

#endif

