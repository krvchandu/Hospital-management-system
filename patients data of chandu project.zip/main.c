#include<stdio.h>
#include "chandufile.h"

int main(){

    struct patient p[100];
    int n=0;
    int choice;

    while(1){

            //-----------manu of management------//

        printf("\n===== Hospital Management =====\n");
        printf("1. Add Patient\n");
        printf("2. Display Patients\n");
        printf("3. Search Patient\n");
        printf("4. Highest Age Patient\n");
        printf("5. Exit\n");

        printf("Enter choice: ");
        scanf("%d",&choice);

        switch(choice){

            case 1:
            addPatient(p,&n);     
            break;

            case 2:
            displayPatient();
            break;

            case 3:
            searchPatient();
            break;

            case 4:
            highestPatient();
            break;

            case 5:
            return 0;

            default:
            printf("Invalid choice\n");
        }
    }
}